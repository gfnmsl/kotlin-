# 本文档是该项目的目录,用于解释各个 包 和 类 的功能

ji suan qi -> src -> main.kt (程序的启动文件)
ji suan qi -> src -> Class -> suanfa.kt (存放计算方法的类)
ji suan qi -> src -> Class -> liuCheng.kt (存放程序的流程控制类)