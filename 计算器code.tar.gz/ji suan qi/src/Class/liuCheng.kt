package Class
// 导入输入输出包
import java.util.*

class liuCheng {
    /*
    *   解释类文件中各个方法的作用:
    *   welcome()   输出欢迎信息
    *   xz()        选择算法
    *   calc()      进行计算
    * */
    fun welcome() {// 欢迎信息
        println("欢迎使用终端计算器,本程序可以进行简单的计算,是作者练习 kotlin 的项目\n需要源码请访问以下链接")
        println("===============================================================================\ngithu:")
        println("https://github.com/gfnmsl/kotlin-Demo\n===============================================================================\ngitee:")
        println("https://gitee.com/songjiaqi233/kotlin-case\n===============================================================================\ngitcode")
        println("https://gitcode.com/songjiaqi/kotlinPJ?ref=main\n===============================================================================")
    }

    fun xz(): Byte {// 选择算法
        println("请选择算法(1.加法 2.减法 3.乘法 4.除法 5.取余)")
        var sc = Scanner(System.`in`)// 创建一个扫描器
        while (true) {
            var xz: Byte = sc.nextByte()// 获取用户输入
            if (xz == 1.toByte()) {// 加法分支

                println("你选择了加法")
                return xz// 返回结果
                break// 跳出循环

            } else if (xz == 2.toByte()) {// 减法分支

                println("你选择了减法")
                return xz//
                break// 跳出循环

            } else if (xz == 3.toByte()) {// 乘法分支

                println("你选择了乘法")
                return xz// 返回结果
                break// 跳出循环

            } else if (xz == 4.toByte()) {// 除法分支

                println("你选择了除法")
                return xz// 返回结果
                break// 跳出循环

            } else if (xz == 5.toByte()) {// 取余分支}

                println("你选择了取余")
                return xz// 返回结果
                break// 跳出循环

            } else {
                println("你输入有误,请重新输入")
            }
        }
    }

    fun calc(a: Byte): Float {// 进行计算
        if (a == 1.toByte()) {// 加法分支
            var b: Float = suanFa().add()// 调用加法方法
            return b// 发挥
        } else if (a == 2.toByte()) {// 减法分支
            var b: Float = suanFa().sub()// 调用减法方法
            return b// 返回结果
        } else if (a == 3.toByte()) {// 乘法分支
            var b: Float =suanFa().mul()// 调用乘法方法
            return b// 返回结果
        } else if (a == 4.toByte()) {// 除法分支
            var b: Float =suanFa().div()// 调用除法方法
            return b// 返回结果
        } else if (a == 5.toByte()) {// 取余分支
            var b: Float =suanFa().mod()// 调用取余方法
            return b// 返回结果
        }

        return TODO("提供返回值")
    }
}