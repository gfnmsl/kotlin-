package Class
// 导入输入输出包
import java.util.*

class suanFa {
    /*
    *   解释类文件中各个方法的作用:
    *   add() 用来计算两个数的和
    *   sub() 用来计算两个数的差
    *   mul() 用来计算两个数的积
    *   div() 用来计算两个数的商
    *   mod() 用来计算两个数的余数
    * */
    open fun add(): Float {
        var sc = Scanner(System.`in`)// 创建一个扫描器
        println("请输入两个数")// 输出提示
        var a: Float = sc.nextFloat()// 输入第一个数
        var b: Float = sc.nextFloat()// 输入第二个数
        println("结果为:${a + b}")// 输出结果
        return a + b// 返回结果
    }

    // 定义一个方法用来计算两个数的差
    fun sub(): Float {
        val sc = Scanner(System.`in`)// 创建一个扫描器
        println("请输入两个数")// 输出提示
        val a: Float = sc.nextFloat()// 输入第一个数
        val b: Float = sc.nextFloat()// 输入第二个数
        println("结果为:${a - b}")// 输出结果
        return a - b// 返回结果
    }

    // 定义一个方法用来计算两个数的积
    fun mul(): Float {
        val sc = Scanner(System.`in`)// 创建一个扫描器
        println("请输入两个数")// 输出提示
        val a: Float = sc.nextFloat()// 输入第一个数
        val b: Float = sc.nextFloat()// 输入第二个数
        println("结果为:${a * b}")// 输出结果
        return a * b// 返回结果
    }

    // 定义一个方法用来计算两个数的商
    fun div(): Float {
        val sc = Scanner(System.`in`)// 创建一个扫描器
        println("请输入两个数")// 输出提示
        val a: Float = sc.nextFloat()// 输入第一个数
        val b: Float = sc.nextFloat()// 输入第二个数
        println("结果为:${a / b}")// 输出结果
        return a / b// 返回结果
    }

    // 定义一个方法用来计算两个数的余数
    fun mod(): Float {
        val sc = Scanner(System.`in`)// 创建一个扫描器
        println("请输入两个数")// 输出提示
        val a: Float = sc.nextFloat()// 输入第一个数
        val b: Float = sc.nextFloat()// 输入第二个数
        println("结果为:${a % b}")// 输出结果
        return a % b// 返回结果
    }
}