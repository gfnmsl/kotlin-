import Class.liuCheng// 导入自定义的包

fun main() {
    liuCheng().welcome()// 导入 liuCheng 类中的 welcome 方法
    var xz: Byte = liuCheng().xz()// 导入 liuCheng 类中的 xz 方法
    var calc = liuCheng().calc(xz)// 导入 liuCheng 类中的 calc 方法
}